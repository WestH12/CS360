package com.example.inventory_hunter_westley;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class InventoryActivity extends AppCompatActivity implements TextWatcher {
    static String DIA = "Add dialog box";
    public ImageButton logOut, settings, increment, decrement, delete;
    Button add;
    RecyclerView rView;
    InventoryDatabase DB;
    MyAdapter adapter;
    ArrayList<String> id, item, number;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        logOut = (ImageButton) findViewById(R.id.logoutButtonInv);
        settings = (ImageButton) findViewById(R.id.settingButtonInv);
        add = findViewById(R.id.addButton);
        rView = findViewById(R.id.recyclerView);
        DB = new InventoryDatabase(this);
        id = new ArrayList<>();
        item = new ArrayList<>();
        number = new ArrayList<>();
        increment = findViewById(R.id.incrementButton);
        decrement = findViewById(R.id.decrementButton);
        delete = findViewById(R.id.itemdelete);
        add = findViewById(R.id.addButton);
        adapter = new MyAdapter(this, id, item, number, delete, increment, decrement, DB, add);
        rView.setHasFixedSize(true);
        rView.setAdapter(adapter);
        rView.setLayoutManager(new LinearLayoutManager(this));
        displayData();


        logOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(InventoryActivity.this, MainActivity.class));
            } } );

        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(InventoryActivity.this, SettingsActivity.class));
            } } );

        add.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                showAddDialog();
            }
        });

    }

    void displayData(){
        id.clear();
        item.clear();
        number.clear();

        Cursor cursor = DB.getData();
        if (cursor.getCount() == 0){
            Toast.makeText(InventoryActivity.this, "No Items", Toast.LENGTH_SHORT).show();
            adapter.notifyDataSetChanged();
            return;
        } else {
            while (cursor.moveToNext()){
                id.add(cursor.getString(0));
                item.add(cursor.getString(1));
                number.add(cursor.getString(2));
            }
        }
        adapter.notifyDataSetChanged();
    }



    private void showAddDialog(){

        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_add, null);

        final EditText editItem = dialogView.findViewById(R.id.editAddItem);
        final EditText editNumber = dialogView.findViewById(R.id.editAddNumber);


        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add New Item");

        builder.setView(dialogView);


        builder.setPositiveButton("Add", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String inItem = editItem.getText().toString();
                String inNumber = editNumber.getText().toString();
                Log.d(DIA, inItem);
                Log.d(DIA, inNumber);

                if ( (!inItem.isEmpty()) & (!inNumber.isEmpty()) ){
                    if (DB.insertItemData(inItem, inNumber)){
                        Toast.makeText(InventoryActivity.this, "Item Added!", Toast.LENGTH_SHORT).show();
                        displayData();
                    };
                }
                else {
                    Toast.makeText(InventoryActivity.this, "Not all item information entered.", Toast.LENGTH_SHORT).show();
                }
            }
        });
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
                Toast.makeText(InventoryActivity.this, "Cancelled", Toast.LENGTH_SHORT).show();
            }
        });

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }


    @Override
    public void afterTextChanged(Editable s) {

    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }
}