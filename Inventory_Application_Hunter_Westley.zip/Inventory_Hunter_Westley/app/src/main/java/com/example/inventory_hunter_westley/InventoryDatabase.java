package com.example.inventory_hunter_westley;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class InventoryDatabase extends SQLiteOpenHelper {
    String TAG = "Increment";
    private Context context;
    private static final String DATABASE_NAME = "inventory.db";
    private static final int VERSION = 1;
    private SettingsActivity settings;
    public InventoryDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
        this.context = context;
        settings = new SettingsActivity();
    }

    private static final class InventoryTable {
        private static final String TABLE = "inventory";
        private static final String COL_ID = "_id";
        private static final String COL_ITEM = "item";
        private static final String COL_NUMBER = "number";

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + InventoryTable.TABLE + "(" +
                InventoryTable.COL_ID + " integer primary key autoincrement, " +
                InventoryTable.COL_ITEM + " TEXT, " +
                InventoryTable.COL_NUMBER + " TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + InventoryTable.TABLE);
        onCreate(db);
    }

    public Boolean insertItemData(String item, String number){
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("item", item);
        contentValues.put("number", number);
        long result = DB.insert("inventory", null, contentValues);
        if (result == -1){
            return false;
        }
        else {
            return true;
        }
    }

    public Cursor getData(){
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = DB.rawQuery("Select * from inventory", null);
        return cursor;
    }

    public Boolean deleteItem(String id){
        SQLiteDatabase DB = this.getWritableDatabase();


        long result = DB.delete(InventoryTable.TABLE, InventoryTable.COL_ID + "= ?", new String[] { String.valueOf(id)});
        DB.close();
        if (result == -1){
            return false;
        }
        else {
            return true;
        }

    }

    public Boolean incrementItem(String id){
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        int currCount = 0;
        Cursor cursor = null;

        cursor = DB.query(
                InventoryTable.TABLE,
                new String[]{InventoryTable.COL_NUMBER},
                InventoryTable.COL_ID + " = ?",
                new String[] {id},
                null, null, null
        );


        if (cursor.moveToFirst()){
            currCount = cursor.getInt(0);
        } else {
            return false;
        }

        values.put(InventoryTable.COL_NUMBER, currCount + 1);
        int rowsAffected = DB.update(
                InventoryTable.TABLE,
                values,
                InventoryTable.COL_ID + " = ?",
                new String[]{id}
        );
        cursor.close();
        DB.close();

        return rowsAffected > 0;
    }

    public Boolean decrementItem(String id, String item){
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        int currCount = 0;
        Cursor cursor = null;


        cursor = DB.query(
                InventoryTable.TABLE,
                new String[]{InventoryTable.COL_NUMBER},
                InventoryTable.COL_ID + " = ?",
                new String[] {id},
                null, null, null
        );


        if (cursor.moveToFirst()){
            currCount = cursor.getInt(0);
        } else {
            return false;
        }

        if (currCount > 0){ //Preventing item count going into negatives
            if (currCount == 6){
                SettingsActivity.sendSMS(context, item);
            }
            values.put(InventoryTable.COL_NUMBER, currCount - 1);
        }
        else {
            return false;
        }

        int rowsAffected = DB.update(
                InventoryTable.TABLE,
                values,
                InventoryTable.COL_ID + " = ?",
                new String[]{id}
        );
        cursor.close();
        DB.close();

        return rowsAffected > 0;
    }
}
