package com.example.inventory_hunter_westley;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements TextWatcher {

    EditText username, password;
    Button logIn, signUp;
    LogInDatabase DB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);


        //Finding and assigning correct editText boxs
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);

        //Finding and assigning the correct buttons
        logIn = findViewById(R.id.login);
        signUp = findViewById(R.id.signup);
        //By default, turning off buttons so the editText fields will require input
        logIn.setEnabled(false);
        signUp.setEnabled(false);

        DB = new LogInDatabase(this);

        username.addTextChangedListener(this);
        password.addTextChangedListener(this);

        logIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = String.valueOf(username.getText());
                String pass = String.valueOf(password.getText());

                if (DB.logIn( user, pass)){
                    startActivity(new Intent(MainActivity.this, InventoryActivity.class));
                } else {
                    Toast.makeText(MainActivity.this, "Log In Failed.", Toast.LENGTH_SHORT).show();
                }

            } } );

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = String.valueOf(username.getText());
                String pass = String.valueOf(password.getText());

                if (DB.signUp(user, pass)){
                    Toast.makeText(MainActivity.this, "Sign Up Successful. Log In Now!", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(MainActivity.this, "Username already tied to an account", Toast.LENGTH_SHORT).show();
                }
            } } );

    }


    @Override
    public void afterTextChanged(Editable s) {
        if ( (username.getText().isEmpty()) | (password.getText().isEmpty())){
            logIn.setEnabled(false);
            signUp.setEnabled(false);
        }
        else {
            logIn.setEnabled(true);
            signUp.setEnabled(true);
        }
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {

    }
}