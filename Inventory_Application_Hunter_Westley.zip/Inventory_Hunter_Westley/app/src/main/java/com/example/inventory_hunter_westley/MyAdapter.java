package com.example.inventory_hunter_westley;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {
    private Context context;
    private ArrayList id_id, item_id, number_id;
    ImageButton increment, decrement, delete;
    static Button add;
    InventoryActivity invA;
    InventoryDatabase DB;
    private String TAG = "DELETE";


    public MyAdapter(Context context, ArrayList id_id, ArrayList item_id, ArrayList number_id, ImageButton delete, ImageButton increment, ImageButton decrement, InventoryDatabase DB, Button add) {
        this.context = context;
        this.id_id = id_id;
        this.item_id = item_id;
        this.number_id = number_id;
        this.delete = delete;
        this.DB = DB;
        this.add = add;
        this.increment = increment;
        this.decrement = decrement;

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.itementry, parent, false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.id_id.setText(String.valueOf(id_id.get(position)));
        holder.item_id.setText(String.valueOf(item_id.get(position)));
        holder.number_id.setText(String.valueOf(number_id.get(position)));

        holder.increment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int currentPos = holder.getBindingAdapterPosition();

                if (currentPos !=  RecyclerView.NO_POSITION){
                    final String itemID = String.valueOf(id_id.get(currentPos));
                   Boolean result = DB.incrementItem(String.valueOf(itemID));

                   if (result){
                       ((InventoryActivity) context).displayData();
                   }
                }
            }
        });

        holder.decrement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int currentPos = holder.getBindingAdapterPosition();

                if (currentPos != RecyclerView.NO_POSITION){
                    final String itemID = String.valueOf(id_id.get(currentPos));
                    final String item = String.valueOf((item_id.get(currentPos)));

                    Boolean result = DB.decrementItem(String.valueOf(itemID), item);

                    if (result){
                        ((InventoryActivity) context).displayData();
                    } else {
                        Toast.makeText(context, "Cannot be negatively decremented.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        holder.delete.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                int currentPos = holder.getBindingAdapterPosition();

                if (currentPos != RecyclerView.NO_POSITION){
                    deleteInventoryItem(currentPos);
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return item_id.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        public ImageButton increment, decrement, delete;
        TextView number_id, item_id, id_id;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            id_id = itemView.findViewById(R.id.itemId);
            item_id = itemView.findViewById(R.id.itemname);
            number_id = itemView.findViewById(R.id.itemnumber);
            add = itemView.findViewById(R.id.addButton);
            increment = itemView.findViewById(R.id.incrementButton);
            decrement = itemView.findViewById(R.id.decrementButton);
            delete = itemView.findViewById(R.id.itemdelete);

        }
    }

    public void deleteInventoryItem(int position){
        String invID = String.valueOf(id_id.get(position));

        if (DB.deleteItem(invID)){
            id_id.remove(position);
            item_id.remove(position);
            number_id.remove(position);

            notifyItemRemoved(position);
        }
    }

}
