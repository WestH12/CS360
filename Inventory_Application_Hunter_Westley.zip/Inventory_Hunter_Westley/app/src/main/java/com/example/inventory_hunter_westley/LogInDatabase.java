package com.example.inventory_hunter_westley;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.Objects;

public class LogInDatabase extends SQLiteOpenHelper {
    private static final String DB_NAME = "login.db";
    private static final int VERSION = 2;

    public LogInDatabase(Context context) {
        super(context, DB_NAME, null, VERSION);

    }

    private static final class LogInTable {
        private static final String TABLE = "login";
        private static final String COL_ID = "_id";
        private static final String COL_USER = "user";
        private static final String COL_PASS = "pass";
    }




    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + LogInTable.TABLE + "(" +
                LogInTable.COL_ID + " integer primary key autoincrement, " +
                LogInTable.COL_USER + " TEXT, " +
                LogInTable.COL_PASS + " TEXT)");
        Boolean result = loadStarterData(db);
        Log.d("STARTER DATA", String.valueOf(result));
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + LogInDatabase.LogInTable.TABLE);
        onCreate(db);
    }

    private Boolean loadStarterData(SQLiteDatabase DB) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(LogInTable.COL_USER, "WHunter");
        contentValues.put(LogInTable.COL_PASS, "SNHU");
        long result = DB.insert(LogInTable.TABLE, null, contentValues);
        if (result == -1){
            return false;
        } else {
            return true;
        }
    }
    public Boolean logIn(String user, String pass){
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor credentials = null;

        try {
            credentials = DB.query(
                    LogInTable.TABLE,
                    new String[]{LogInTable.COL_PASS},
                    LogInTable.COL_USER + " = ?",
                    new String[] {user},
                    null, null, null
                    );
            if (credentials.moveToFirst()){
                DB.close();
                return (Objects.equals(credentials.getString(0), pass));
            } else {
                Log.d("LOGIN", "Failed to move to first item");
                credentials.close();
                DB.close();
                return false;
            }
        } catch (Exception e){
            Log.d("LOGIN ERROR", String.valueOf(e));
            return false;
        }
    }

    public Boolean signUp(String user, String pass){
        SQLiteDatabase DB = this.getWritableDatabase();
        Cursor cursor = null;

        try {
            cursor = DB.query(
                    LogInTable.TABLE,
                    new String[]{LogInTable.COL_USER},
                    LogInTable.COL_USER + " = ?",
                    new String[] {user},
                    null, null, null
            );
            if (cursor.getCount() > 0){
                return false;
            }
        } catch (Exception e) {        }

        ContentValues values = new ContentValues();
        values.put(LogInTable.COL_USER, user);
        values.put(LogInTable.COL_PASS, pass);
        DB.insert(LogInTable.TABLE, null, values);
        DB.close();
        return true;
    }
}
