package com.example.inventory_hunter_westley;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.jetbrains.annotations.NonNls;

import java.util.ArrayList;
import java.util.List;

import kotlin.collections.ArrayDeque;

public class SettingsActivity extends AppCompatActivity {
    private final static int PERMISSION_CODE = 1234;
    ImageButton logOut, database;
    Switch smsSwitch;
    private static final String number = "6505551212";
    public static final String PREFS_NAME = "SMS_Prefs";
    public static final String KEY_SMS_STATUS = "sms_enabled";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        logOut = findViewById(R.id.logoutButtonSet);
        database = findViewById(R.id.databaseButtonSet);
        smsSwitch = findViewById(R.id.smsSwitch);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            smsSwitch.setChecked(true);
        } else {
            smsSwitch.setChecked(false);
        }

        logOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SettingsActivity.this, MainActivity.class));

            }
        });

        database.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SettingsActivity.this, InventoryActivity.class));

            }
        });

        smsSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(@NonNull CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    requestPermission();
                } else {
                    getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                                    .putBoolean(KEY_SMS_STATUS, false)
                                            .apply();
                    Toast.makeText(SettingsActivity.this, "SMS Disabled", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void requestPermission(){
        Log.d("PERMISSION", "TEST");
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    PERMISSION_CODE);
        }
        else {
            getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                    .putBoolean(KEY_SMS_STATUS, true)
                    .apply();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults){
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSION_CODE){
            boolean permissionGranted = (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED);

            getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit()
                    .putBoolean(KEY_SMS_STATUS, permissionGranted)
                    .apply();

            if (permissionGranted){
                Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS Permission Denied", Toast.LENGTH_SHORT).show();
                smsSwitch.setChecked(false);
            }
        }
    }

    public static void sendSMS(Context context, String item){
        Boolean isSMSEnabled = context.getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                .getBoolean(KEY_SMS_STATUS, false);

        Boolean hasSystemPermission = ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;

        if (isSMSEnabled & hasSystemPermission){
            String message = "ALERT: " + item + "'s inventory is below 5 items";
            Log.d("SMS", message);
            SmsManager smsManager = context.getSystemService(SmsManager.class);
            smsManager.sendTextMessage(number, null, message, null, null);
        } else {
            Log.d("SMS", "No SMS Permission");
        }
    }
}


